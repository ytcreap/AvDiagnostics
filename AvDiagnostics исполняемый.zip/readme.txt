1. Запускаем install.sh от лица суперпользователя (sudo). Необходимо для работы guardant, иначе никак
2. Проверяем config.xml
3. Можем запускать AvDiagnosticsTest

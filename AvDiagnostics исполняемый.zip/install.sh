#!/bin/sh

echo "*********************************************************************"
echo " Starting the installation of Test product..."
echo "*********************************************************************"

iconsPath="/usr/share/icons/hicolor"
desktopPath="/usr/share/applications" 
installPath="/opt/helloworld"
linkPath="/usr/bin/helloworld"

gtk-update-icon-cache /usr/share/icons/hicolor
update-desktop-database
echo "*********************************************************************"
echo " Copy 95-grdnt.rules and libgrdlic.so"
echo "*********************************************************************"

sudo cp ./95-grdnt.rules /etc/udev/rules.d
sudo cp ./libgrdlic.so /usr/lib

echo "*********************************************************************"
echo " Reload udev rules without restarting udev "
echo "*********************************************************************"

sudo udevadm control --reload-rules
sudo udevadm trigger --subsystem-match=usb --action=add

echo "*********************************************************************"
echo " You must reconnect dongle "
echo "*********************************************************************"
